from flask import Flask
from .db import mysql  # Ensure this import is correct
from my_project.auth.route.user_routes import auth_bp  # Import the auth blueprint
import yaml

def create_app():
    app = Flask(__name__)

    # Load configurations and initialize mysql
    with open("app/config/app.yml", 'r') as file:
        config = yaml.safe_load(file)
    app.config['MYSQL_HOST'] = config['database']['host']
    app.config['MYSQL_USER'] = config['database']['user']
    app.config['MYSQL_PASSWORD'] = config['database']['password']
    app.config['MYSQL_DB'] = 'lab3'  # Your database name

    mysql.init_app(app)  # Initialize MySQL

    # Register the Blueprint
    app.register_blueprint(auth_bp)  # Keep this registration

    return app
