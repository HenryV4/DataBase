from app import create_app
from my_project.auth.route.user_routes import auth_bp  # Import the blueprint
from .db import mysql

app = create_app()  # Create the Flask app

@app.route('/')
def home():
    return "Welcome to the Home Page!", 200

@app.route('/test_mysql')
def test_mysql():
    try:
        cur = mysql.connection.cursor()
        cur.execute("SELECT DATABASE()")
        result = cur.fetchone()
        return f"Connected to database: {result[0]}", 200
    except Exception as e:
        return f"Error connecting to MySQL: {str(e)}", 500

if __name__ == "__main__":
    app.run(debug=True)
