from flask import Flask
from flask_mysqldb import MySQL
import yaml

mysql = MySQL()

def init_app(app: Flask):
    # Load YAML configurations
    with open("app/config/app.yml", 'r') as file:
        config = yaml.safe_load(file)

    # MySQL Configurations
    app.config['MYSQL_HOST'] = config['database']['host']
    app.config['MYSQL_USER'] = config['database']['user']
    app.config['MYSQL_PASSWORD'] = config['database']['password']
    app.config['MYSQL_DB'] = 'lab3'  # Change this to your lab3 database name

    # Initialize MySQL
    mysql.init_app(app)
