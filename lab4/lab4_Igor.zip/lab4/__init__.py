from flask import Flask
from . import init_app, mysql  # Import init_app and mysql from db.py

def create_app():
    app = Flask(__name__)
    
    # Initialize the app with MySQL
    init_app(app)

    # Register your blueprints, etc.
    # from my_project.auth.route.user_routes import auth_bp
    # app.register_blueprint(auth_bp)

    return app