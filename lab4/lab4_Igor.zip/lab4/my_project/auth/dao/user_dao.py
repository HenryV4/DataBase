
class LocationDAO:
    def __init__(self, mysql_instance):
        self.mysql = mysql_instance

    def get_all_locations(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM location")
        locations = cur.fetchall()
        cur.close()
        return locations

    def insert_location(self, city, country):
        cur = self.mysql.connection.cursor()
        cur.execute("INSERT INTO location (city, country) VALUES (%s, %s)", (city, country))
        self.mysql.connection.commit()
        cur.close()

    def update_location(self, location_id, city, country):
        cur = self.mysql.connection.cursor()
        cur.execute("UPDATE location SET city=%s, country=%s WHERE id=%s", (city, country, location_id))
        self.mysql.connection.commit()
        cur.close()

    def delete_location(self, location_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM location WHERE id=%s", (location_id,))
        self.mysql.connection.commit()
        cur.close()


class ChainDAO:
    def __init__(self, mysql_instance):
        self.mysql = mysql_instance

    def get_all_chains(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM chain")
        chains = cur.fetchall()
        cur.close()
        return chains

    def insert_chain(self, name):
        cur = self.mysql.connection.cursor()
        cur.execute("INSERT INTO chain (name) VALUES (%s)", (name,))
        self.mysql.connection.commit()
        cur.close()

    def update_chain(self, chain_id, name):
        cur = self.mysql.connection.cursor()
        cur.execute("UPDATE chain SET name=%s WHERE id=%s", (name, chain_id))
        self.mysql.connection.commit()
        cur.close()

    def delete_chain(self, chain_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM chain WHERE id=%s", (chain_id,))
        self.mysql.connection.commit()
        cur.close()


class HotelDAO:
    def __init__(self, mysql_instance):
        self.mysql = mysql_instance

    def get_all_hotels(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM hotel")
        hotels = cur.fetchall()
        cur.close()
        return hotels

    def insert_hotel(self, name, address, room_num, location_id, stars, chain_id):
        cur = self.mysql.connection.cursor()
        cur.execute("INSERT INTO hotel (name, address, room_num, location_id, stars, chain_id) VALUES (%s, %s, %s, %s, %s, %s)",
                    (name, address, room_num, location_id, stars, chain_id))
        self.mysql.connection.commit()
        cur.close()

    def update_hotel(self, hotel_id, name, address, room_num, location_id, stars, chain_id):
        cur = self.mysql.connection.cursor()
        cur.execute("UPDATE hotel SET name=%s, address=%s, room_num=%s, location_id=%s, stars=%s, chain_id=%s WHERE id=%s",
                    (name, address, room_num, location_id, stars, chain_id, hotel_id))
        self.mysql.connection.commit()
        cur.close()

    def delete_hotel(self, hotel_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM hotel WHERE id=%s", (hotel_id,))
        self.mysql.connection.commit()
        cur.close()


class RoomDAO:
    def __init__(self, mysql_instance):
        self.mysql = mysql_instance

    def get_all_rooms(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM room")
        rooms = cur.fetchall()
        cur.close()
        return rooms

    def insert_room(self, room_type, price_per_night, available, hotel_id):
        cur = self.mysql.connection.cursor()
        cur.execute("INSERT INTO room (room_type, price_per_night, available, hotel_id) VALUES (%s, %s, %s, %s)",
                    (room_type, price_per_night, available, hotel_id))
        self.mysql.connection.commit()
        cur.close()

    def update_room(self, room_id, room_type, price_per_night, available, hotel_id):
        cur = self.mysql.connection.cursor()
        cur.execute("UPDATE room SET room_type=%s, price_per_night=%s, available=%s, hotel_id=%s WHERE id=%s",
                    (room_type, price_per_night, available, hotel_id, room_id))
        self.mysql.connection.commit()
        cur.close()

    def delete_room(self, room_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM room WHERE id=%s", (room_id,))
        self.mysql.connection.commit()
        cur.close()


class DiscountCardDAO:
    def __init__(self, mysql_instance):
        self.mysql = mysql_instance

    def get_all_discount_cards(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM discount_cards")
        cards = cur.fetchall()
        cur.close()
        return cards

    def insert_discount_card(self, name, discount):
        cur = self.mysql.connection.cursor()
        cur.execute("INSERT INTO discount_cards (name, discount) VALUES (%s, %s)", (name, discount))
        self.mysql.connection.commit()
        cur.close()

    def update_discount_card(self, card_id, name, discount):
        cur = self.mysql.connection.cursor()
        cur.execute("UPDATE discount_cards SET name=%s, discount=%s WHERE id=%s", (name, discount, card_id))
        self.mysql.connection.commit()
        cur.close()

    def delete_discount_card(self, card_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM discount_cards WHERE id=%s", (card_id,))
        self.mysql.connection.commit()
        cur.close()


class ClientDAO:
    def __init__(self, mysql_instance):
        self.mysql = mysql_instance

    def get_all_clients(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM client")
        clients = cur.fetchall()
        cur.close()
        return clients

    def insert_client(self, full_name, email, phone_num, discount_cards_id):
        cur = self.mysql.connection.cursor()
        cur.execute("INSERT INTO client (full_name, email, phone_num, discount_cards_id) VALUES (%s, %s, %s, %s)",
                    (full_name, email, phone_num, discount_cards_id))
        self.mysql.connection.commit()
        cur.close()

    def update_client(self, client_id, full_name, email, phone_num, discount_cards_id):
        cur = self.mysql.connection.cursor()
        cur.execute("UPDATE client SET full_name=%s, email=%s, phone_num=%s, discount_cards_id=%s WHERE id=%s",
                    (full_name, email, phone_num, discount_cards_id, client_id))
        self.mysql.connection.commit()
        cur.close()

    def delete_client(self, client_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM client WHERE id=%s", (client_id,))
        self.mysql.connection.commit()
        cur.close()
        
    def get_clients_by_city(self, city):
        cur = self.mysql.connection.cursor()
        cur.execute("""
            SELECT c.full_name, l.city
            FROM client c
            LEFT JOIN booking b ON c.id = b.client_id
            LEFT JOIN room r ON b.room_id = r.id
            LEFT JOIN hotel h ON r.hotel_id = h.id
            LEFT JOIN location l ON h.location_id = l.id
            WHERE l.city = %s
        """, (city,))
        clients = cur.fetchall()
        cur.close()
        return clients

class PaymentDAO:
    def __init__(self, mysql_instance):
        self.mysql = mysql_instance

    def get_all_payments(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM payment")
        payments = cur.fetchall()
        cur.close()
        return payments

    def insert_payment(self, card_number, payment_amount, payment_date, status, client_id):
        cur = self.mysql.connection.cursor()
        cur.execute("INSERT INTO payment (card_number, payment_amount, payment_date, status, client_id) VALUES (%s, %s, %s, %s, %s)",
                    (card_number, payment_amount, payment_date, status, client_id))
        self.mysql.connection.commit()
        cur.close()

    def update_payment(self, payment_id, card_number, payment_amount, payment_date, status, client_id):
        cur = self.mysql.connection.cursor()
        cur.execute("UPDATE payment SET card_number=%s, payment_amount=%s, payment_date=%s, status=%s, client_id=%s WHERE id=%s",
                    (card_number, payment_amount, payment_date, status, client_id, payment_id))
        self.mysql.connection.commit()
        cur.close()

    def delete_payment(self, payment_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM payment WHERE id=%s", (payment_id,))
        self.mysql.connection.commit()
        cur.close()


class BookingDAO:
    def __init__(self, mysql_instance):
        self.mysql = mysql_instance

    def get_all_bookings(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM booking")
        bookings = cur.fetchall()
        cur.close()
        return bookings

    def insert_booking(self, check_in_date, check_out_date, total_price, room_id, client_id, payment_id):
        cur = self.mysql.connection.cursor()
        cur.execute("INSERT INTO booking (check_in_date, check_out_date, total_price, room_id, client_id, payment_id) VALUES (%s, %s, %s, %s, %s, %s)",
                    (check_in_date, check_out_date, total_price, room_id, client_id, payment_id))
        self.mysql.connection.commit()
        cur.close()

    def update_booking(self, booking_id, check_in_date, check_out_date, total_price, room_id, client_id, payment_id):
        cur = self.mysql.connection.cursor()
        cur.execute("UPDATE booking SET check_in_date=%s, check_out_date=%s, total_price=%s, room_id=%s, client_id=%s, payment_id=%s WHERE id=%s",
                    (check_in_date, check_out_date, total_price, room_id, client_id, payment_id, booking_id))
        self.mysql.connection.commit()
        cur.close()

    def delete_booking(self, booking_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM booking WHERE id=%s", (booking_id,))
        self.mysql.connection.commit()
        cur.close()


class ReviewDAO:
    def __init__(self, mysql_instance):
        self.mysql = mysql_instance

    def get_all_reviews(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM review")
        reviews = cur.fetchall()
        cur.close()
        return reviews

    def insert_review(self, rating, comment, client_id, hotel_id):
        cur = self.mysql.connection.cursor()
        cur.execute("INSERT INTO review (rating, comment, client_id, hotel_id) VALUES (%s, %s, %s, %s)",
                    (rating, comment, client_id, hotel_id))
        self.mysql.connection.commit()
        cur.close()

    def update_review(self, review_id, rating, comment, client_id, hotel_id):
        cur = self.mysql.connection.cursor()
        cur.execute("UPDATE review SET rating=%s, comment=%s, client_id=%s, hotel_id=%s WHERE id=%s",
                    (rating, comment, client_id, hotel_id, review_id))
        self.mysql.connection.commit()
        cur.close()

    def delete_review(self, review_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM review WHERE id=%s", (review_id,))
        self.mysql.connection.commit()
        cur.close()


class AmenitiesDAO:
    def __init__(self, mysql_instance):
        self.mysql = mysql_instance

    def get_all_amenities(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM amenities")
        amenities = cur.fetchall()
        cur.close()
        return amenities

    def insert_amenity(self, name):
        cur = self.mysql.connection.cursor()
        cur.execute("INSERT INTO amenities (name) VALUES (%s)", (name,))
        self.mysql.connection.commit()
        cur.close()

    def update_amenity(self, amenity_id, name):
        cur = self.mysql.connection.cursor()
        cur.execute("UPDATE amenities SET name=%s WHERE id=%s", (name, amenity_id))
        self.mysql.connection.commit()
        cur.close()

    def delete_amenity(self, amenity_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM amenities WHERE id=%s", (amenity_id,))
        self.mysql.connection.commit()
        cur.close()

class HotelAmenitiesDAO:
    def __init__(self, mysql_instance):
        self.mysql = mysql_instance

    def get_all_hotel_amenities(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM hotel_has_amenities")
        amenities = cur.fetchall()
        cur.close()
        return amenities

    def insert_hotel_amenity(self, hotel_id, amenities_id):
        cur = self.mysql.connection.cursor()
        cur.execute("INSERT INTO hotel_has_amenities (hotel_id, amenities_id) VALUES (%s, %s)", (hotel_id, amenities_id))
        self.mysql.connection.commit()
        cur.close()

    def update_hotel_amenity(self, hotel_id, amenities_id, new_amenities_id):
        cur = self.mysql.connection.cursor()
        cur.execute(
            "UPDATE hotel_has_amenities SET amenities_id=%s WHERE hotel_id=%s AND amenities_id=%s",
            (new_amenities_id, hotel_id, amenities_id)
        )
        self.mysql.connection.commit()
        cur.close()

    def delete_hotel_amenity(self, hotel_id, amenities_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM hotel_has_amenities WHERE hotel_id=%s AND amenities_id=%s", (hotel_id, amenities_id))
        self.mysql.connection.commit()
        cur.close()

    def get_amenities_for_hotel(self, hotel_id):
        cur = self.mysql.connection.cursor()
        cur.execute(
            """
            SELECT a.name
            FROM amenities a
            JOIN hotel_has_amenities ha ON a.id = ha.amenities_id
            WHERE ha.hotel_id = %s
            """
            , (hotel_id,))
        amenities = cur.fetchall()
        cur.close()
        return amenities