from flask import Blueprint, request, jsonify
from my_project.auth.dao.user_dao import (
    LocationDAO, ChainDAO, HotelDAO, RoomDAO, DiscountCardDAO,
    ClientDAO, PaymentDAO, BookingDAO, ReviewDAO, AmenitiesDAO, HotelAmenitiesDAO
)
from app.db import mysql

auth_bp = Blueprint('unique_auth_bp', __name__)

# Instantiate DAO classes
location_dao = LocationDAO(mysql)
chain_dao = ChainDAO(mysql)
hotel_dao = HotelDAO(mysql)
room_dao = RoomDAO(mysql)
discount_card_dao = DiscountCardDAO(mysql)
client_dao = ClientDAO(mysql)
payment_dao = PaymentDAO(mysql)
booking_dao = BookingDAO(mysql)
review_dao = ReviewDAO(mysql)
amenities_dao = AmenitiesDAO(mysql)
hotel_amenities_dao = HotelAmenitiesDAO(mysql)

# ========================= Location Routes =========================
@auth_bp.route('/locations', methods=['GET'])
def get_locations():
    return jsonify(location_dao.get_all_locations()), 200

@auth_bp.route('/locations', methods=['POST'])
def create_location():
    data = request.get_json()
    location_dao.insert_location(data['city'], data['country'])
    return jsonify({'message': 'Location created successfully!'}), 201

@auth_bp.route('/locations/<int:location_id>', methods=['PUT'])
def update_location(location_id):
    data = request.get_json()
    location_dao.update_location(location_id, data['city'], data['country'])
    return jsonify({'message': 'Location updated successfully!'}), 200

@auth_bp.route('/locations/<int:location_id>', methods=['DELETE'])
def delete_location(location_id):
    location_dao.delete_location(location_id)
    return jsonify({'message': 'Location deleted successfully!'}), 200

# ========================= Chain Routes =========================
@auth_bp.route('/chains', methods=['GET'])
def get_chains():
    return jsonify(chain_dao.get_all_chains()), 200

@auth_bp.route('/chains', methods=['POST'])
def create_chain():
    data = request.get_json()
    chain_dao.insert_chain(data['name'])
    return jsonify({'message': 'Chain created successfully!'}), 201

@auth_bp.route('/chains/<int:chain_id>', methods=['PUT'])
def update_chain(chain_id):
    data = request.get_json()
    chain_dao.update_chain(chain_id, data['name'])
    return jsonify({'message': 'Chain updated successfully!'}), 200

@auth_bp.route('/chains/<int:chain_id>', methods=['DELETE'])
def delete_chain(chain_id):
    chain_dao.delete_chain(chain_id)
    return jsonify({'message': 'Chain deleted successfully!'}), 200

# ========================= Hotel Routes =========================
@auth_bp.route('/hotels', methods=['GET'])
def get_hotels():
    return jsonify(hotel_dao.get_all_hotels()), 200

@auth_bp.route('/hotels', methods=['POST'])
def create_hotel():
    data = request.get_json()
    hotel_dao.insert_hotel(
        data['name'], 
        data['address'], 
        data['room_num'], 
        data['location_id'], 
        data['stars'], 
        data['chain_id']
    )
    return jsonify({'message': 'Hotel created successfully!'}), 201

@auth_bp.route('/hotels/<int:hotel_id>', methods=['PUT'])
def update_hotel(hotel_id):
    data = request.get_json()
    hotel_dao.update_hotel(
        hotel_id,
        data['name'],
        data['address'],
        data['room_num'],
        data['location_id'],
        data['stars'],
        data['chain_id']
    )
    return jsonify({'message': 'Hotel updated successfully!'}), 200

@auth_bp.route('/hotels/<int:hotel_id>', methods=['DELETE'])
def delete_hotel(hotel_id):
    hotel_dao.delete_hotel(hotel_id)
    return jsonify({'message': 'Hotel deleted successfully!'}), 200

# ========================= Room Routes =========================
@auth_bp.route('/rooms', methods=['GET'])
def get_rooms():
    return jsonify(room_dao.get_all_rooms()), 200

@auth_bp.route('/rooms', methods=['POST'])
def create_room():
    data = request.get_json()
    room_dao.insert_room(
        data['room_type'],
        data['price_per_night'],
        data['available'],
        data['hotel_id']
    )
    return jsonify({'message': 'Room created successfully!'}), 201

@auth_bp.route('/rooms/<int:room_id>', methods=['PUT'])
def update_room(room_id):
    data = request.get_json()
    room_dao.update_room(
        room_id,
        data['room_type'],
        data['price_per_night'],
        data['available'],
        data['hotel_id']
    )
    return jsonify({'message': 'Room updated successfully!'}), 200

@auth_bp.route('/rooms/<int:room_id>', methods=['DELETE'])
def delete_room(room_id):
    room_dao.delete_room(room_id)
    return jsonify({'message': 'Room deleted successfully!'}), 200

# ========================= Discount Card Routes =========================
@auth_bp.route('/discount_cards', methods=['GET'])
def get_discount_cards():
    return jsonify(discount_card_dao.get_all_discount_cards()), 200

@auth_bp.route('/discount_cards', methods=['POST'])
def create_discount_card():
    data = request.get_json()
    discount_card_dao.insert_discount_card(data['name'], data['discount'])
    return jsonify({'message': 'Discount card created successfully!'}), 201

@auth_bp.route('/discount_cards/<int:card_id>', methods=['PUT'])
def update_discount_card(card_id):
    data = request.get_json()
    discount_card_dao.update_discount_card(card_id, data['name'], data['discount'])
    return jsonify({'message': 'Discount card updated successfully!'}), 200

@auth_bp.route('/discount_cards/<int:card_id>', methods=['DELETE'])
def delete_discount_card(card_id):
    discount_card_dao.delete_discount_card(card_id)
    return jsonify({'message': 'Discount card deleted successfully!'}), 200

# ========================= Client Routes =========================
@auth_bp.route('/clients', methods=['GET'])
def get_clients():
    return jsonify(client_dao.get_all_clients()), 200

@auth_bp.route('/clients', methods=['POST'])
def create_client():
    data = request.get_json()
    client_dao.insert_client(data['full_name'], data['email'], data['phone_num'], data.get('discount_cards_id'))
    return jsonify({'message': 'Client created successfully!'}), 201

@auth_bp.route('/clients/<int:client_id>', methods=['PUT'])
def update_client(client_id):
    data = request.get_json()
    client_dao.update_client(client_id, data['full_name'], data['email'], data['phone_num'], data.get('discount_cards_id'))
    return jsonify({'message': 'Client updated successfully!'}), 200

@auth_bp.route('/clients/<int:client_id>', methods=['DELETE'])
def delete_client(client_id):
    client_dao.delete_client(client_id)
    return jsonify({'message': 'Client deleted successfully!'}), 200

@auth_bp.route('/clients/<city>', methods=['GET'])
def get_clients_by_city(city):
    clients = client_dao.get_clients_by_city(city)
    return jsonify(clients), 200

# ========================= Payment Routes =========================
@auth_bp.route('/payments', methods=['GET'])
def get_payments():
    return jsonify(payment_dao.get_all_payments()), 200

@auth_bp.route('/payments', methods=['POST'])
def create_payment():
    data = request.get_json()
    payment_dao.insert_payment(data['card_number'], data['payment_amount'], data['payment_date'], data['status'], data['client_id'])
    return jsonify({'message': 'Payment created successfully!'}), 201

@auth_bp.route('/payments/<int:payment_id>', methods=['PUT'])
def update_payment(payment_id):
    data = request.get_json()
    payment_dao.update_payment(payment_id, data['card_number'], data['payment_amount'], data['payment_date'], data['status'], data['client_id'])
    return jsonify({'message': 'Payment updated successfully!'}), 200

@auth_bp.route('/payments/<int:payment_id>', methods=['DELETE'])
def delete_payment(payment_id):
    payment_dao.delete_payment(payment_id)
    return jsonify({'message': 'Payment deleted successfully!'}), 200

# ========================= Booking Routes =========================
@auth_bp.route('/bookings', methods=['GET'])
def get_bookings():
    return jsonify(booking_dao.get_all_bookings()), 200

@auth_bp.route('/bookings', methods=['POST'])
def create_booking():
    data = request.get_json()
    booking_dao.insert_booking(data['check_in_date'], data['check_out_date'], data['total_price'], data['room_id'], data['client_id'], data['payment_id'])
    return jsonify({'message': 'Booking created successfully!'}), 201

@auth_bp.route('/bookings/<int:booking_id>', methods=['PUT'])
def update_booking(booking_id):
    data = request.get_json()
    booking_dao.update_booking(booking_id, data['check_in_date'], data['check_out_date'], data['total_price'], data['room_id'], data['client_id'], data['payment_id'])
    return jsonify({'message': 'Booking updated successfully!'}), 200

@auth_bp.route('/bookings/<int:booking_id>', methods=['DELETE'])
def delete_booking(booking_id):
    booking_dao.delete_booking(booking_id)
    return jsonify({'message': 'Booking deleted successfully!'}), 200

# ========================= Review Routes =========================
@auth_bp.route('/reviews', methods=['GET'])
def get_reviews():
    return jsonify(review_dao.get_all_reviews()), 200

@auth_bp.route('/reviews', methods=['POST'])
def create_review():
    data = request.get_json()
    review_dao.insert_review(data['rating'], data.get('comment'), data['client_id'], data['hotel_id'])
    return jsonify({'message': 'Review created successfully!'}), 201

@auth_bp.route('/reviews/<int:review_id>', methods=['PUT'])
def update_review(review_id):
    data = request.get_json()
    review_dao.update_review(review_id, data['rating'], data.get('comment'), data['client_id'], data['hotel_id'])
    return jsonify({'message': 'Review updated successfully!'}), 200

@auth_bp.route('/reviews/<int:review_id>', methods=['DELETE'])
def delete_review(review_id):
    review_dao.delete_review(review_id)
    return jsonify({'message': 'Review deleted successfully!'}), 200

# ========================= Amenities Routes =========================
@auth_bp.route('/amenities', methods=['GET'])
def get_amenities():
    return jsonify(amenities_dao.get_all_amenities()), 200

@auth_bp.route('/amenities', methods=['POST'])
def create_amenity():
    data = request.get_json()
    amenities_dao.insert_amenity(data['name'])
    return jsonify({'message': 'Amenity created successfully!'}), 201

@auth_bp.route('/amenities/<int:amenity_id>', methods=['PUT'])
def update_amenity(amenity_id):
    data = request.get_json()
    amenities_dao.update_amenity(amenity_id, data['name'])
    return jsonify({'message': 'Amenity updated successfully!'}), 200

@auth_bp.route('/amenities/<int:amenity_id>', methods=['DELETE'])
def delete_amenity(amenity_id):
    amenities_dao.delete_amenity(amenity_id)
    return jsonify({'message': 'Amenity deleted successfully!'}), 200

# ========================= Hotel Amenities Routes =========================
@auth_bp.route('/hotel_amenities', methods=['GET'])
def get_all_hotel_amenities():  # Renamed function
    return jsonify(hotel_amenities_dao.get_all_hotel_amenities()), 200

@auth_bp.route('/hotel_amenities', methods=['POST'])
def create_hotel_amenity():
    data = request.get_json()
    hotel_amenities_dao.insert_hotel_amenity(data['hotel_id'], data['amenities_id'])
    return jsonify({'message': 'Hotel amenity created successfully!'}), 201

@auth_bp.route('/hotel_amenities/<int:hotel_id>/<int:amenities_id>', methods=['PUT'])
def update_hotel_amenity(hotel_id, amenities_id):
    data = request.get_json()
    new_amenities_id = data['new_amenities_id']
    hotel_amenities_dao.update_hotel_amenity(hotel_id, amenities_id, new_amenities_id)
    return jsonify({'message': 'Hotel amenity updated successfully!'}), 200

@auth_bp.route('/hotel_amenities', methods=['DELETE'])
def delete_hotel_amenity():
    data = request.get_json()
    hotel_amenities_dao.delete_hotel_amenity(data['hotel_id'], data['amenities_id'])
    return jsonify({'message': 'Hotel amenity deleted successfully!'}), 200

@auth_bp.route('/hotel_amenities/<int:hotel_id>', methods=['GET'])
def get_hotel_amenities(hotel_id):
    amenities = hotel_amenities_dao.get_amenities_for_hotel(hotel_id)
    return jsonify(amenities), 200